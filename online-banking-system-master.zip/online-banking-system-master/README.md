# MCB

MCB is a lightweight core banking application that powers banking operations like account creation, customer deposit and withdrawals.

The app is meant to support a single bank, where users can signup and create ban accounts online, but must visit the branch to withdraw or deposit money.

## UI

The UI of the app comes first.
![WhatsApp Image 2022-11-06 at 11 36 54 PM (4)](https://user-images.githubusercontent.com/81613701/200896064-215e1ab3-e441-43db-9ec0-e6184529a365.jpeg)
![WhatsApp Image 2022-11-06 at 11 36 54 PM](https://user-images.githubusercontent.com/81613701/200896218-28026b5a-ed32-4571-b2e1-e5d12988e596.jpeg)
![WhatsApp Image 2022-11-06 at 11 36 54 PM (2)](https://user-images.githubusercontent.com/81613701/200896532-6cddb1b2-e240-4bba-9dce-5a0ba63606da.jpeg)
![WhatsApp Image 2022-11-06 at 11 36 54 PM (5)](https://user-images.githubusercontent.com/81613701/200896613-959fd207-905d-4da5-be43-f649725a3f93.jpeg)
![WhatsApp Image 2022-11-06 at 11 36 55 PM (1)](https://user-images.githubusercontent.com/81613701/200896717-5d02b55a-5ac3-46e7-bc37-e864d09514cf.jpeg)
