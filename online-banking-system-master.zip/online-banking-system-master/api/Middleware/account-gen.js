/** Generate account number function */
const generateAccountNumber = () => Math.floor(Math.random() * 1e10);

export default generateAccountNumber;
