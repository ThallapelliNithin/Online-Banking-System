export default {
  Admin: 'Admin',
  Staff: 'Staff',
  Client: 'Client',
};
