import 'dotenv/config';

const secret = process.env.JWT_SECRET;

export default secret;
